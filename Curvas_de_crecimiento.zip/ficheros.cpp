#include <iostream>
#include <cstdlib>
#include <math.h>
#include "fstream"
#include "string"
#include<iomanip>//para manipular el setw
using namespace std;


int main(){
//input file stream "ifstream": Crea un archivo de entrada de solo lectura
//miFichero("ruta")
ifstream miFichero("datos_santa.csv");
int m=349, n=4;
double A[m][4], pro[3];
double cont[]={0,0,0};
//Es como un cin miFichero>>A[i][j];
for(int i=0;i<m;i++){
        for(int j=0;j<n;j++){
                miFichero>>A[i][j];
		//cout<<A[i][j]<<" ";
		}
//cout<<endl;
	}
//Se cierra el archivo porque sino se puede danar
miFichero.close();
//Enviar info a un archivo plano
//off file stream
ofstream miFichero2;
ofstream miFichero3;
ofstream miFichero4;
//miFichero2.open : Lo crea y lo abre
miFichero2.open("curva_144.csv");
miFichero3.open("curva_145.csv");
miFichero4.open("curva_147.csv");

//setw(): reserva para cada dato 10 lugares
for(int i=0;i<m;i++){
	if(A[i][1]==144){
		if(cont[0]==0){
        		for(int j=0;j<n;j++)
				pro[0]=A[i][2];
			cont[0]++;
		}
		A[i][2]=A[i][2]-pro[0];
        	for(int j=0;j<n;j++)
                	miFichero2<<setw(11)<<A[i][j]<<",";
		miFichero2<<endl;
	}
	if(A[i][1]==145){
		if(cont[1]==0){
        		for(int j=0;j<n;j++)
				pro[1]=A[i][2];
			cont[1]++;
		}
		A[i][2]=A[i][2]-pro[1];
        	for(int j=0;j<n;j++)
                	miFichero3<<setw(11)<<A[i][j]<<",";
		miFichero3<<endl;
	}
	if(A[i][1]==147){
		if(cont[2]==0){
        		for(int j=0;j<n;j++)
				pro[2]=A[i][2];
			cont[2]++;
		}
		A[i][2]=A[i][2]-pro[2];
        	for(int j=0;j<n;j++)
                	miFichero4<<setw(11)<<A[i][j]<<",";
		miFichero4<<endl;
	}
        }
for(int i=0;i<3;i++)
	cout<<pro[i]<<" ";
miFichero2.close();
miFichero3.close();
miFichero4.close();
system("Pause");
return 0;
}
